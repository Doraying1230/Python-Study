#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "6d91c1655"     # abbreviated commit hash
commit = "6d91c16551c837d80de3e0e8f236b08bec7ab02f"  # commit hash
date = "2018-03-25 22:49:43 +0200"   # commit date
author = "Hartmut Goebel <h.goebel@crazy-compilers.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Tests: Remove 'xfail' from test_openpyxl.

Issue #2363 (recursion to deep in modulegraph was solved quite some
some ago.
"""
