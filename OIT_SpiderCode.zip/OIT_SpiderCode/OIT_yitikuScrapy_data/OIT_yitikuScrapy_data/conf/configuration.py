# -*- coding: utf-8 -*-
####################################################################
# Script    : Configuration
# PURPOSE   : A wrap up program for scrapy crawler
#
# CREATED:    2017-12-27    EnfangQi
#
#
# MODIFIED
# DATE        AUTHOR            DESCRIPTION
# -------------------------------------------------------------------
#
#####################################################################
from ..common.BaseObject import BaseObject
class Configuration(BaseObject):
    SpiderName = {'PerSpiderName':'None'}
configurationS= Configuration()