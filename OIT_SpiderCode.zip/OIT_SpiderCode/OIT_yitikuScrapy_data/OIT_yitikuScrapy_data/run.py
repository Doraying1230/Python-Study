import scrapy.cmdline
scrapy.cmdline.execute(argv=['scrapy','crawl','yitiku_middle_math_data'])