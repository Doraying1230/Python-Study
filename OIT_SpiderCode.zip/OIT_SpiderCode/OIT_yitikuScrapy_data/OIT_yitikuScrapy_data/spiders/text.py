#coding:utf-8
from fake_useragent import UserAgent
import  requests
if __name__ =="__main__":
    a = {1:2,3:4}
    print(len(a))
    # url ='http://www.yitiku.cn/uploads/word_import/images/280/1420621782n6KEpNFm5WWHSaOSEHgv.jpg'
    # ua = UserAgent()
    # user_agent = ua.random
    # cookie = {'pgv_pvi': '8869029888', 'tencentSig': '8349357056', 'PHPSESSID': '21rbna3k500ic89ga8qjmqhjs3',
    #                'pgv_si': 's8352073728', 'IESESSION': 'alive', '_qddamta_800024201': '3-0',
    #                'jiami_userid': 'NjkzMzE0fDk1NzM5YmM5MzIwYjY1ZmViZmE3NDQ3ZmVkY2E4NTY3', 'account': '18621942417',
    #                'password': 'MTIzNDU2',
    #                'ytkuser': '%7B%22id%22%3A%22693314%22%2C%22deadline%22%3A%220%22%2C%22feature%22%3A%22f5ee54afd56eef93b9db72a134881074%22%7D',
    #                '_qddaz': 'QD.s08ddj.bmtxtt.jcbcp2wi', '_qdda': '3-1.1', '_qddab': '3-se1uzy.jcslbnnd',
    #                'Hm_lvt_ba430f404e1018c19017fd7d6857af83': '1515726959,1516586108,1516605643,1516759114',
    #                'Hm_lpvt_ba430f404e1018c19017fd7d6857af83': '1516769535'}
    # headers = {
    #     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    #     'User-Agent': user_agent,
    #     'Host':'yitikuimage.oss-cn-qingdao.aliyuncs.com',
    #     # 'Cookie':'pgv_pvi=8869029888; tencentSig=8349357056; PHPSESSID=21rbna3k500ic89ga8qjmqhjs3; pgv_si=s8352073728; IESESSION=alive; jiami_userid=NjkzMzE0fDk1NzM5YmM5MzIwYjY1ZmViZmE3NDQ3ZmVkY2E4NTY3; account=18621942417; password=MTIzNDU2; ytkuser=%7B%22id%22%3A%22693314%22%2C%22deadline%22%3A%220%22%2C%22feature%22%3A%22f5ee54afd56eef93b9db72a134881074%22%7D; Hm_lvt_ba430f404e1018c19017fd7d6857af83=1515726959,1516586108,1516605643,1516759114; Hm_lpvt_ba430f404e1018c19017fd7d6857af83=1516786814; _qddaz=QD.s08ddj.bmtxtt.jcbcp2wi; _qddab=3-p4vgy5.jcsva6ms'
    #
    # }
    #
    # c = requests.get(url='http://yitikuimage.oss-cn-qingdao.aliyuncs.com/201601/20/596520374380387426915460279810128251304096631727051178937',headers=headers)
    # with open('1.jpg','wb') as f:
    #     f.write(c.content)
    #



