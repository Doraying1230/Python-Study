#coding:utf-8
import scrapy.cmdline
scrapy.cmdline.execute(argv=['scrapy','crawl','zujuan_yuwen_data'])