import scrapy.cmdline
scrapy.cmdline.execute(argv=['scrapy','crawl','21cnjy_param'])