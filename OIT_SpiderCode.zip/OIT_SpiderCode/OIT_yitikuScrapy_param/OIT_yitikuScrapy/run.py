import scrapy.cmdline
scrapy.cmdline.execute(argv=['scrapy','crawl','yiTiKu_param'])