#coding:utf-8

set_1=([1,2,3])
set_1=set ([1,2,3])
print set_1
set_1.add('hello')
print 'add后',set_1
set_1.update('hello')
print 'updatehou ',set_1