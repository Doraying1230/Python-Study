#coding:utf-8
num = 0
while num<100:
    num += 1
    print num
    if num==50:
        # break  跳出当前的while语句循环
        break

        
    