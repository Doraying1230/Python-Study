#coding:utf-8
# print '今天差点下雪'
# print '今天差点下雪'
# print '今天差点下雪'
# print '今天差点下雪'
# print '今天差点下雪'
# print '今天差点下雪'
# print '今天差点下雪'
# print '今天差点下雪'
# print '今天差点下雪'
# print '今天差点下雪'

# while 条件:
#     pass
num = 0
# 只要num<10条件成立，会不停的执行下去；条件不成立就跳出while语句
while num<10:
    print '今天差点下雪'
    # 每执行一次，num都会在原来的基础上+1
    # num = num + 1 和下边的 num +=1 等价
    num += 1


    # num ++  不支持
    # ++ num  不支持
    print num


