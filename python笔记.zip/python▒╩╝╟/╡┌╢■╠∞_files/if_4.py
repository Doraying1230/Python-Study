#coding:utf-8

#  小正太，小鲜肉，长腿欧巴，老腊肉，老大爷
# nian_ling
# age
# years
age = input('请输入年龄:')

if age<18:
    print '小正太'
elif age<28:
    print '小鲜肉'
elif age<38:
    print '长腿欧巴'
elif age<48:
    print '老腊肉'
else:
    print '老大爷'

